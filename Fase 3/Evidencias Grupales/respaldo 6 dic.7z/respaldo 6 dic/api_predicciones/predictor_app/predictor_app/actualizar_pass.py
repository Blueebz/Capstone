from django.core.management.base import BaseCommand
from django.contrib.auth.hashers import make_password
from predictor_app.models import Usuario


class Command(BaseCommand):
    help = 'Actualiza las contraseñas de los usuarios almacenadas sin cifrar a un formato cifrado'

    def handle(self, *args, **kwargs):
        usuarios = Usuario.objects.all()
        for usuario in usuarios:
            usuario.password = make_password(usuario.password)
            usuario.save()
        self.stdout.write(self.style.SUCCESS('Contraseñas actualizadas con éxito.'))
