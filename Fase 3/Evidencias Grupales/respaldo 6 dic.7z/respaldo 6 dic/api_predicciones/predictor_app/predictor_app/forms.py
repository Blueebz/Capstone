from django import forms
from .models import Usuario

class UsuarioForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = [
            'rut_numero', 'rut_dv', 'primer_nombre', 'segundo_nombre',
            'apellido_p', 'apellido_m', 'fecha_cumpleanos', 'email',
            'password', 'tipo_usuario', 'inmobiliaria_asociada', 
            'is_active', 'is_admin'
        ]
