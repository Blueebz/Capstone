from django.shortcuts import redirect

# middleware.py

class LoginRequiredMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Excepciones para no requerir login en ciertas rutas
        excluded_paths = [
            "/login/", "/index/", "/",  # Asegúrate de incluir todas las rutas posibles del index
            "/static/",  # Permite el acceso a archivos estáticos
        ]

        if not request.user.is_authenticated and not any(request.path.startswith(path) for path in excluded_paths):
            return redirect('custom_login')

        response = self.get_response(request)
        return response
