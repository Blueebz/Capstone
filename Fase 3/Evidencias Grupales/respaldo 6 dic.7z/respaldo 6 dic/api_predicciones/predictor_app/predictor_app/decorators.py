from django.shortcuts import redirect
from datetime import datetime
from .models import Pago

def requiere_pago_aprobado(view_func):
    def wrapper(request, *args, **kwargs):
        usuario_id = request.session.get('usuario_id')
        if not usuario_id:
            return redirect('custom_login')

        # Comprobar si el usuario tiene un pago válido
        pagos = Pago.objects.filter(usuario_id=usuario_id, estado='Aprobado', valido_hasta__gte=datetime.now())
        if not pagos.exists():
            return redirect('index')  # Redirige al index si no tiene un pago válido
        
        return view_func(request, *args, **kwargs)
    return wrapper
