import dash
from dash import dcc, html, Input, Output, State
import plotly.express as px
import pandas as pd
import plotly.graph_objects as go
import flask
import numpy as np
import dash_bootstrap_components as dbc  # Para la grilla

# Crear la aplicación de Dash
server = flask.Flask(__name__)
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

# Cargar el DataFrame
df = pd.read_csv('C:\\Users\\slade\\Downloads\\inmo_scrap\\anaconda\\api_predicciones\\df_filtered_predicciones_2_no_zero_superficie.csv')

# Obtener la lista de comunas únicas
comunas_unicas = df['Comuna'].unique()

# Gráfico de precios mínimos y máximos
precios_min_max = df.groupby('Comuna')['Precio UF'].agg(['min', 'max']).reset_index()
fig3 = go.Figure()
fig3.add_trace(go.Bar(x=precios_min_max['Comuna'], y=precios_min_max['min'], name='Mínimo', marker_color='blue'))
fig3.add_trace(go.Bar(x=precios_min_max['Comuna'], y=precios_min_max['max'], name='Máximo', marker_color='red'))
fig3.update_layout(
    title='Precios Mínimo y Máximo UF por Comuna',
    xaxis_title='Comuna',
    yaxis_title='Precio UF',
    barmode='group',
    xaxis_tickangle=-45
)

# Layout de la aplicación
app.layout = dbc.Container([
    html.H1('Dashboard de Precios Inmobiliarios', className='text-center mb-4'),


    # Contenedor de gráficos
    html.Div(id="graphs-container", children=[
        dbc.Row([
            dbc.Col(dcc.Graph(id='scatter-graph', figure=px.scatter(
                df, x='Superficie', y='Precio UF', title='Relación entre Superficie y Precio UF').update_layout(
                xaxis_title='Superficie (m²)', yaxis_title='Precio UF')), width=6),
            dbc.Col(dcc.Graph(id='histogram-graph', figure=px.histogram(
                df, x='Precio UF', nbins=50, title='Distribución de Precios UF').update_layout(
                xaxis_title='Precio UF', yaxis_title='Frecuencia')), width=6)
        ]),
        dbc.Row([
            dbc.Col(dcc.Graph(id='boxplot-graph', figure=px.box(
                df, x='Comuna', y='Precio UF', title='Distribución de Precios UF por Comuna').update_layout(
                xaxis_title='Comuna', yaxis_title='Precio UF', xaxis_tickangle=-45)), width=6),
            dbc.Col(dcc.Graph(id='bar-graph', figure=fig3), width=6)
        ]),
        dbc.Row([
            dbc.Col(html.Div([
                html.H2('Generar gráfico por comuna específica', className='text-center'),
                dcc.Dropdown(
                    id='comuna-dropdown-specific',
                    options=[{'label': comuna, 'value': comuna} for comuna in comunas_unicas],
                    placeholder='Seleccione una comuna'
                ),
                html.Button('Generar Gráfico', id='submit-button-specific', n_clicks=0),
                dcc.Graph(id='specific-comuna-graph')
            ]), width=12)
        ]),
        dbc.Row([
            dbc.Col(html.Div([
                html.H2('Precio Promedio vs Superficie por Comuna', className='text-center'),
                dcc.Dropdown(
                    id='superficie-comuna-dropdown',
                    options=[{'label': 'Todas', 'value': 'Todas'}] + [{'label': comuna, 'value': comuna} for comuna in comunas_unicas],
                    placeholder='Seleccione una comuna',
                    value='Todas'  # Predeterminado para mostrar todas
                ),
                dcc.Graph(id='promedio-superficie-graph')
            ]), width=12)
        ])
    ])
], fluid=True)


# Callback para actualizar el gráfico por comuna específica
@app.callback(
    Output('specific-comuna-graph', 'figure'),
    [Input('submit-button-specific', 'n_clicks')],
    [State('comuna-dropdown-specific', 'value')]
)
def update_specific_comuna_graph(n_clicks, comuna):
    if n_clicks > 0 and comuna:
        df_comuna = df[df['Comuna'] == comuna]
        if df_comuna.empty:
            return go.Figure(layout=go.Layout(title=f'No se encontraron datos para la comuna: {comuna}'))

        fig = px.histogram(df_comuna, x='Precio UF', nbins=20, title=f'Distribución de Precios UF en {comuna}')
        fig.update_layout(xaxis_title='Precio UF', yaxis_title='Frecuencia', bargap=0.2)
        return fig
    return go.Figure()

# Callback para precio promedio vs superficie por comuna
@app.callback(
    Output('promedio-superficie-graph', 'figure'),
    [Input('superficie-comuna-dropdown', 'value')]
)
def update_promedio_superficie_graph(comuna_seleccionada):
    try:
        df_ajustado = df.copy()
        df_ajustado['Superficie'] = df_ajustado['Superficie'].apply(lambda x: round(x) if x % 1 >= 0.5 else int(x))
        superficie_bins = np.linspace(df_ajustado['Superficie'].min(), df_ajustado['Superficie'].max(), 10)
        superficie_bins = [round(b) for b in superficie_bins]

        fig = go.Figure()

        if comuna_seleccionada == 'Todas':
            for comuna in comunas_unicas:
                df_comuna = df_ajustado[df_ajustado['Comuna'] == comuna]
                if df_comuna.empty:
                    continue
                df_comuna['Superficie_Binned'] = pd.cut(df_comuna['Superficie'], bins=superficie_bins)
                promedio_precio_por_bin = df_comuna.groupby('Superficie_Binned')['Precio UF'].mean()
                fig.add_trace(go.Scatter(
                    x=[f'{int(bin.left)} - {int(bin.right)}' for bin in promedio_precio_por_bin.index],
                    y=promedio_precio_por_bin,
                    mode='lines+markers',
                    name=comuna
                ))
        else:
            df_comuna = df_ajustado[df_ajustado['Comuna'] == comuna_seleccionada]
            if df_comuna.empty:
                return go.Figure(layout=go.Layout(title=f'No se encontraron datos para la comuna: {comuna_seleccionada}'))
            df_comuna['Superficie_Binned'] = pd.cut(df_comuna['Superficie'], bins=superficie_bins)
            promedio_precio_por_bin = df_comuna.groupby('Superficie_Binned')['Precio UF'].mean()
            fig.add_trace(go.Scatter(
                x=[f'{int(bin.left)} - {int(bin.right)}' for bin in promedio_precio_por_bin.index],
                y=promedio_precio_por_bin,
                mode='lines+markers',
                name=comuna_seleccionada
            ))

        fig.update_layout(
            title='Precio Promedio vs Superficie por Comuna',
            xaxis_title='Rango de Superficie (m²)',
            yaxis_title='Precio Promedio (UF)',
            xaxis_tickangle=-45,
            legend_title='Comuna'
        )

        return fig

    except Exception as e:
        return go.Figure(layout=go.Layout(title=f'Error: {str(e)}'))

# Ejecutar la aplicación
if __name__ == '__main__':
    app.run_server(debug=True, port=8050)
