
from django.http import JsonResponse,  HttpResponse
from django.views.decorators.csrf import csrf_exempt
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import json
import pandas as pd
import pickle
from django.shortcuts import render,  get_object_or_404, redirect
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64

#Creacion de usuarios 
from django.contrib.auth.hashers import make_password
from .forms import UsuarioForm
from django.views.decorators.csrf import csrf_exempt


#Protección de datos
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from .serializers import CustomTokenObtainPairSerializer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView

import os
import pickle

#Admin
from .models import Usuario
from django.contrib import messages

#Logout
from django.contrib.auth import logout
from django.shortcuts import redirect

#Pago
from django.shortcuts import render, redirect
from .models import Pago, Usuario
from django.utils import timezone
from django.contrib import messages

#decorador de pagos
from .decorators import requiere_pago_aprobado
from datetime import timedelta
from datetime import datetime

#registrar usuario

from .models import Usuario, TipoUsuario, Inmobiliaria
from django.utils.crypto import get_random_string
import hashlib

#dashboard flask
from django.shortcuts import redirect


import joblib
from django.conf import settings

#predicciones
from django.views.decorators.csrf import csrf_exempt
import json
import pandas as pd
from django.http import JsonResponse
import joblib
import os


from sklearn.model_selection import train_test_split

#api_analisis
from django.template.loader import render_to_string


df = pd.read_csv('C:\\Users\\slade\\Downloads\\inmo_scrap\\anaconda\\api_predicciones\\df_filtered_predicciones_2_no_zero_superficie.csv')
# Obtener la ruta base del proyecto
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Definir la ruta relativa del archivo modelo_regresion_lineal.pkl
modelo_path = os.path.join(BASE_DIR, 'predictor_app', 'modelo_regresion_lineal_2.pkl')

# Cargar el modelo
modelo = joblib.load(modelo_path)

# Características usadas durante el entrenamiento del modelo
columnas_modelo = ["Baños", "Dormitorios", "Superficie", "Estacionamiento", 
                   "La Reina", "Providencia", "Nunoa", "Vitacura", 
                   "Lo Barnechea", "Las Condes"]
# Cargar el modelo desde la ruta relativa
try:
    with open(modelo_path, 'rb') as f:
        modelo = pickle.load(f)
except FileNotFoundError:
    print(f"Error: No se pudo encontrar el archivo del modelo en la ruta: {modelo_path}")
    modelo = None  # Si no se encuentra el archivo, asignamos None para evitar errores posteriores

@requiere_pago_aprobado
def regresion_lineal(request):
    # Verificar si el modelo fue cargado correctamente
    if modelo is None:
        return JsonResponse({'error': 'El modelo de regresión lineal no se pudo cargar. Verifique la existencia del archivo.'}, status=500)

    # Definir X con las variables independientes y Y como la dependiente
    X = df[['Baños', 'Dormitorios', 'Superficie', 'Estacionamiento', 
            'La Reina', 'Providencia', 'Nunoa', 'Vitacura', 'Lo Barnechea', 'Las Condes']]
    Y = df['Precio UF']

    # Dividir en conjunto de prueba (solo para evaluación)
    _, X_test, _, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

    # Ya no entrenamos el modelo, solo hacemos la predicción usando el modelo cargado desde pickle
    try:
        Y_pred = modelo.predict(X_test)
    except Exception as e:
        return JsonResponse({'error': 'Error durante la predicción con el modelo.', 'detalles': str(e)}, status=500)

    # Preparar la respuesta con los resultados de las predicciones
    resultado = {
        "coeficiente_R2": modelo.score(X_test, Y_test),
        "predicciones": Y_pred.tolist(),
    }

    return JsonResponse(resultado)

@csrf_exempt
def predecir_precio(request):
    if request.method == "POST":
        # Obtener los datos del JSON enviado por POST
        try:
            data = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse({"error": "JSON inválido"}, status=400)

        # Crear un DataFrame a partir de los datos recibidos
        df_nueva_prediccion = pd.DataFrame([data])

        # Manejar la columna 'Comuna' para convertirla en columnas one-hot
        comuna = data.get("Comuna")
        if comuna:
            for col in ["La Reina", "Providencia", "Nunoa", "Vitacura", "Lo Barnechea", "Las Condes"]:
                df_nueva_prediccion[col] = 1 if comuna == col else 0
        else:
            return JsonResponse({"error": "Comuna no especificada o inválida"}, status=400)

        # Asegurarse de que el DataFrame tiene las columnas necesarias en el mismo orden
        df_nueva_prediccion = df_nueva_prediccion.reindex(columns=columnas_modelo, fill_value=0)

        try:
            # Realizar la predicción usando el modelo cargado
            prediccion = modelo.predict(df_nueva_prediccion)

            # Devolver la predicción como respuesta JSON con 2 decimales y en UF
            resultado = {
                "prediccion": f"{prediccion[0]:.2f} UF"  # Asumiendo que solo hay una fila de datos
            }
            return JsonResponse(resultado)

        except ValueError as e:
            return JsonResponse({"error": f"Error al realizar la predicción: {str(e)}"}, status=500)

    return JsonResponse({"error": "Método no permitido"}, status=405)

@requiere_pago_aprobado
def grafico_distribucion_precios(request):
    # Cargar el archivo CSV
    

    # Generar el gráfico de distribución usando Seaborn
    plt.figure(figsize=(10, 6))
    sns.histplot(df['Precio UF'], kde=True)  # Histograma con estimación de densidad

    # Guardar el gráfico en un buffer de memoria
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)

    # Devolver el gráfico como imagen
    return HttpResponse(buffer, content_type='image/png')

# Devolver los datos de precios en formato JSON
@requiere_pago_aprobado
def distribucion_precios_json(request):
    # Cargar el archivo CSV
    

    # Obtener los precios para devolver como JSON
    precios = df['Precio UF'].tolist()
    return JsonResponse({'precios': precios})

@requiere_pago_aprobado
def mostrar_grafico_html(request):
    return render(request, 'predicciones/grafico.html')

@requiere_pago_aprobado
def metricas_modelo(request):
    # Verificar si el modelo fue cargado correctamente
    if modelo is None:
        return JsonResponse({'error': 'El modelo de regresión lineal no se pudo cargar. Verifique la existencia del archivo.'}, status=500)

    # Definir X y Y
    X = df[columnas_modelo]
    Y = df['Precio UF']
    
    # Dividir en conjuntos de entrenamiento y prueba
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)
    
    # Calcular métricas
    try:
        coef_R2 = round(modelo.score(X_test, Y_test), 2)
        Y_pred = modelo.predict(X_test)
        mse = mean_squared_error(Y_test, Y_pred)
    except AttributeError as e:
        return JsonResponse({'error': 'Error durante la predicción con el modelo.', 'detalles': str(e)}, status=500)
    
    # Retornar métricas
    resultado = {
        "coeficiente_R2": coef_R2,
        "mean_squared_error": mse
    }
    return JsonResponse(resultado)


@requiere_pago_aprobado
def distribucion_precios_por_comuna(request):
    # Agrupar los precios por comuna y calcular la distribución
    distribucion = df.groupby('Comuna')['Precio UF'].describe()  # Aquí puedes ajustar la agregación si quieres mostrar otros estadísticos
    
    # Convertir a un diccionario para enviar como JSON
    distribucion_dict = distribucion.to_dict()

    return JsonResponse(distribucion_dict, safe=False)

@requiere_pago_aprobado
def distribucion_precios_por_comuna_grafico(request):
    # Agrupar los precios por comuna y calcular la distribución
    distribucion = df.groupby('Comuna')['Precio UF'].describe()

    # Convertir a diccionario para devolver como JSON
    distribucion_dict = distribucion.to_dict()

    # Crear el gráfico con seaborn
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='Comuna', y='Precio UF', data=df)
    plt.title('Distribución de Precios UF por Comuna')
    plt.xticks(rotation=45)

    # Guardar la imagen en un buffer
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)

    # Codificar la imagen en base64 para incluirla en el HTML
    image_png = buffer.getvalue()
    buffer.close()
    graphic = base64.b64encode(image_png).decode('utf-8')

    # Devolver tanto el gráfico en HTML como la respuesta JSON con la distribución
    if request.GET.get('json', False):  # Si se agrega ?json a la URL, se devuelve solo JSON
        return JsonResponse(distribucion_dict, safe=False)
    else:
        return render(request, 'predicciones/grafico_distribucion.html', {'graphic': graphic})
    
@requiere_pago_aprobado
def precios_min_max_por_comuna(request):
    # Agrupar los precios por comuna y calcular el mínimo y máximo
    precios_min_max = df.groupby('Comuna')['Precio UF'].agg(['min', 'max']).reset_index()

    # Convertir a diccionario para devolver como JSON
    precios_min_max_dict = precios_min_max.to_dict(orient='records')

    # Crear el gráfico de barras con matplotlib para diferenciar entre mínimo y máximo
    plt.figure(figsize=(10, 6))
    
    # Definir el ancho de las barras
    bar_width = 0.35

    # Posición de las barras en el eje X
    communes = precios_min_max['Comuna']
    r1 = range(len(communes))  # Posición para el mínimo
    r2 = [x + bar_width for x in r1]  # Posición para el máximo

    # Crear las barras
    plt.bar(r1, precios_min_max['min'], color='blue', width=bar_width, edgecolor='grey', label='Mínimo')
    plt.bar(r2, precios_min_max['max'], color='red', width=bar_width, edgecolor='grey', label='Máximo')

    # Añadir etiquetas y título
    plt.xlabel('Comuna', fontweight='bold')
    plt.ylabel('Precio UF')
    plt.xticks([r + bar_width / 2 for r in range(len(communes))], communes, rotation=45)
    plt.title('Precios Mínimo y Máximo UF por Comuna')
    plt.legend()

    # Guardar la imagen en un buffer
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)

    # Codificar la imagen en base64 para incluirla en el HTML
    image_png = buffer.getvalue()
    buffer.close()
    graphic = base64.b64encode(image_png).decode('utf-8')

    # Devolver tanto el gráfico en HTML como la respuesta JSON con el mínimo y máximo
    if request.GET.get('json', False):  # Si se agrega ?json a la URL, se devuelve solo JSON
        return JsonResponse(precios_min_max_dict, safe=False)
    else:
        return render(request, 'predicciones/grafico_min_max.html', {'graphic': graphic})

    
@csrf_exempt
@requiere_pago_aprobado
def distribucion_precio_por_comuna_especifica(request):
    if request.method == 'POST':
        # Obtenemos la comuna del cuerpo del POST en formato JSON
        try:
            data = json.loads(request.body.decode('utf-8'))
            comuna = data.get('comuna')

            if comuna:
                # Filtrar el dataframe para obtener solo los datos de la comuna específica
                df_comuna = df[df['Comuna'] == comuna]

                if df_comuna.empty:
                    return JsonResponse({'error': f'No se encontraron datos para la comuna {comuna}.'}, status=404)

                # Calcular la distribución de precios (describe) para la comuna filtrada
                distribucion = df_comuna['Precio UF'].describe()

                # Convertir a diccionario para devolver como JSON
                distribucion_dict = distribucion.to_dict()

                # Devolver la distribución de la comuna en formato JSON
                return JsonResponse(distribucion_dict, safe=False)
            else:
                return JsonResponse({'error': 'Comuna no especificada.'}, status=400)
        except Exception as e:
            return JsonResponse({'error': 'Ocurrió un error procesando la solicitud.', 'detalles': str(e)}, status=500)
    else:
        return JsonResponse({'error': 'Método no permitido. Use POST.'}, status=405)
    
@requiere_pago_aprobado
def precios_min_max_por_comuna_json(request):
    # Agrupar los precios por comuna y calcular el mínimo y máximo
    precios_min_max = df.groupby('Comuna')['Precio UF'].agg(['min', 'max']).reset_index()

    # Convertir a diccionario para devolver como JSON
    precios_min_max_dict = precios_min_max.to_dict(orient='records')

    # Devolver la respuesta en formato JSON
    return JsonResponse(precios_min_max_dict, safe=False)


@csrf_exempt
@requiere_pago_aprobado
def precios_min_max_por_comuna_post(request):
    if request.method == 'POST':
        try:
            # Obtener el cuerpo de la solicitud como JSON
            data = json.loads(request.body)
            comuna = data.get('comuna')
        except json.JSONDecodeError:
            return JsonResponse({"error": "Solicitud inválida, no es JSON válido"}, status=400)

        # Verificar si se ha proporcionado la comuna
        if not comuna:
            return JsonResponse({"error": "Comuna no proporcionada"}, status=400)

        # Filtrar los datos por la comuna especificada
        comuna_df = df[df['Comuna'] == comuna]

        # Verificar si existen datos para esa comuna
        if comuna_df.empty:
            return JsonResponse({"error": f"No se encontraron datos para la comuna {comuna}"}, status=404)

        # Calcular los valores mínimo y máximo, asegurando que sean tipos de Python nativos
        min_precio = float(comuna_df['Precio UF'].min())
        max_precio = float(comuna_df['Precio UF'].max())

        # Devolver la respuesta en formato JSON
        resultado = {
            "Comuna": comuna,
            "min": min_precio,
            "max": max_precio
        }

        return JsonResponse(resultado)

    return JsonResponse({"error": "Método no permitido"}, status=405)

#Creación de usuarios
@csrf_exempt
def registrar_usuario(request):
    if request.method == 'POST':
        try:
            # Obtener los datos del JSON
            data = json.loads(request.body)

            # Validar y guardar el formulario de usuario
            form = UsuarioForm(data)
            if form.is_valid():
                # Encriptar la contraseña antes de guardar
                usuario = form.save(commit=False)
                usuario.password = make_password(data['password'])  # Encriptar la contraseña
                usuario.save()

                # Generar un token JWT
                refresh = RefreshToken.for_user(usuario)
                return JsonResponse({
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                    'mensaje': 'Usuario creado con éxito.'
                })
            else:
                return JsonResponse({'error': 'Datos inválidos.', 'detalles': form.errors}, status=400)

        except Exception as e:
            return JsonResponse({'error': 'Ocurrió un error al registrar el usuario.', 'detalles': str(e)}, status=500)
    
    return JsonResponse({'error': 'Método no permitido. Use POST.'}, status=405)

#Protección de datos
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def datos_protegidos(request):
    return JsonResponse({'mensaje': 'Acceso concedido. Solo usuarios autenticados pueden ver esto.'})

class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer


# Custom login
def custom_login(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        try:
            # Buscar el usuario en la tabla 'usuarios'
            usuario = Usuario.objects.get(email=username)

            # Para los usuarios existentes sin cifrado de contraseñas (backwards compatibility)
            if usuario.password == password:
                request.session['usuario_id'] = usuario.id
                if usuario.is_admin:
                    return redirect('admin_dashboard')
                else:
                    return redirect('index')

            # Para los nuevos usuarios que tienen contraseña cifrada con salt
            hashed_password = hashlib.sha256((password + usuario.salt).encode()).hexdigest()
            if usuario.password == hashed_password:
                request.session['usuario_id'] = usuario.id
                if usuario.is_admin:
                    return redirect('admin_dashboard')
                else:
                    return redirect('index')

            # Si ninguna coincide, enviar mensaje de error
            messages.error(request, "Contraseña incorrecta")

        except Usuario.DoesNotExist:
            messages.error(request, "Usuario no encontrado")

    return render(request, 'registration/login.html')

#Logout
def custom_logout(request):
    if 'usuario_id' in request.session:
        del request.session['usuario_id']  # Elimina la información del usuario de la sesión
    return redirect('index')  # Redirigir al index



#acciones Admin
def admin_dashboard(request):
    usuario_id = request.session.get('usuario_id')
    if not usuario_id:
        return redirect('custom_login')  # Redirige al login si el usuario no está autenticado
    
    usuario = Usuario.objects.get(pk=usuario_id)
    if not usuario.is_admin:
        return redirect('index')  # Redirige al index si el usuario no es administrador

    # Obtener todos los usuarios para mostrar en el dashboard del administrador
    usuarios = Usuario.objects.all()
    return render(request, 'admin/admin_dashboard.html', {'usuarios': usuarios, 'usuario_actual': usuario})


def editar_usuario(request, user_id):
    usuario_id = request.session.get('usuario_id')
    if not usuario_id:
        return redirect('custom_login')  # Redirige al login si el usuario no está autenticado

    usuario_actual = Usuario.objects.get(pk=usuario_id)  # Obtener el usuario actual
    
    usuario = get_object_or_404(Usuario, id=user_id)
    if request.method == 'POST':
        usuario.primer_nombre = request.POST['primer_nombre']
        usuario.segundo_nombre = request.POST['segundo_nombre']
        usuario.apellido_paterno = request.POST['apellido_paterno']
        usuario.apellido_materno = request.POST['apellido_materno']
        usuario.email = request.POST['email']
        usuario.is_active = 'is_active' in request.POST
        usuario.is_admin = 'is_admin' in request.POST
        usuario.save()
        messages.success(request, 'Usuario actualizado con éxito.')
        return redirect('admin_dashboard')

    return render(request, 'admin/editar_usuario.html', {'usuario': usuario, 'usuario_actual': usuario_actual})

def eliminar_usuario(request, user_id):
    usuario_id = request.session.get('usuario_id')
    if not usuario_id:
        return redirect('custom_login')
    
    admin_usuario = Usuario.objects.get(pk=usuario_id)
    if not admin_usuario.is_admin:
        return redirect('user_dashboard')  # Solo admins pueden eliminar usuarios

    usuario = get_object_or_404(Usuario, id=user_id)
    usuario.delete()
    messages.success(request, 'Usuario eliminado con éxito.')
    return redirect('admin_dashboard')


def activar_usuario(request, user_id):
    usuario_id = request.session.get('usuario_id')
    if not usuario_id:
        return redirect('custom_login')
    
    admin_usuario = Usuario.objects.get(pk=usuario_id)
    if not admin_usuario.is_admin:
        return redirect('user_dashboard')  # Solo admins pueden activar o desactivar usuarios

    usuario = get_object_or_404(Usuario, id=user_id)
    usuario.is_active = not usuario.is_active
    usuario.save()
    messages.success(request, 'Estado de activación del usuario actualizado con éxito.')
    return redirect('admin_dashboard')

#Vista del index

def index(request):
    usuario_actual = None
    if 'usuario_id' in request.session:
        usuario_actual = Usuario.objects.get(pk=request.session['usuario_id'])
    return render(request, 'index.html', {'usuario_actual': usuario_actual})

#Procesar pago
# Vista para procesar el pago del usuario
def procesar_pago(request):
    usuario_id = request.session.get('usuario_id')
    if not usuario_id:
        return redirect('custom_login')

    usuario = Usuario.objects.get(pk=usuario_id)

    # Crear un registro de pago simulado como aprobado
    fecha_actual = timezone.now()
    fecha_expiracion = fecha_actual + timedelta(days=30)  # Suscripción válida por 30 días

    Pago.objects.create(
        usuario=usuario,
        monto=10000,  # Precio de suscripción simulado
        estado='Aprobado',  # Aquí se usa `estado` en vez de `estado_pago`
        fecha_pago=fecha_actual,
        valido_hasta=fecha_expiracion,
        metodo_pago='Tarjeta de Crédito'
    )

    # Mensaje de éxito
    messages.success(request, "¡Pago procesado con éxito! Ahora puedes acceder a las funcionalidades premium.")

    return redirect('user_dashboard')

#Vista usuario dashboard
def user_dashboard(request):
    usuario_id = request.session.get('usuario_id')
    if not usuario_id:
        return redirect('custom_login')  # Redirige al login si el usuario no está autenticado

    try:
        usuario = Usuario.objects.get(pk=usuario_id)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado. Por favor, inicia sesión nuevamente.")
        return redirect('custom_login')

    # Verificar si el usuario tiene un pago aprobado válido
    pagos = Pago.objects.filter(usuario=usuario, estado='Aprobado', valido_hasta__gte=datetime.now())
    if not pagos.exists():
        messages.error(request, "Necesitas un pago aprobado para acceder al dashboard del usuario.")
        return redirect('index')

    return render(request, 'user_dashboard.html', {'usuario_actual': usuario})

#formulario para registrar usuario

def registrar_usuario(request):
    if request.method == 'POST':
        # Recoger los datos del formulario
        rut_numero = request.POST['rut_numero']
        rut_dv = request.POST['rut_dv']
        primer_nombre = request.POST['primer_nombre']
        segundo_nombre = request.POST.get('segundo_nombre', '')
        apellido_p = request.POST['apellido_p']
        apellido_m = request.POST.get('apellido_m', '')
        fecha_cumpleanos = request.POST['fecha_cumpleanos']
        email = request.POST['email']
        password = request.POST['password']
        tipo_usuario_id = request.POST['tipo_usuario']
        inmobiliaria_asociada_id = request.POST.get('inmobiliaria_asociada', None)

        # Validación: verificar si el correo ya está registrado
        if Usuario.objects.filter(email=email).exists():
            messages.error(request, 'Este correo ya está registrado. Por favor, utiliza otro correo.')
            return redirect('registrar_usuario')

        # Hashing de la contraseña antes de guardarla
        salt = get_random_string(12)
        hashed_password = hashlib.sha256((password + salt).encode()).hexdigest()

        # Crear el usuario
        usuario = Usuario(
            rut_numero=rut_numero,
            rut_dv=rut_dv,
            primer_nombre=primer_nombre,
            segundo_nombre=segundo_nombre,
            apellido_p=apellido_p,
            apellido_m=apellido_m,
            fecha_cumpleanos=fecha_cumpleanos,
            email=email,
            password=hashed_password,
            salt=salt,  # Guardar el salt
            tipo_usuario_id=tipo_usuario_id,
            inmobiliaria_asociada_id=inmobiliaria_asociada_id,
        )
        usuario.save()

        messages.success(request, 'Usuario registrado exitosamente. Ahora puedes iniciar sesión.')
        return redirect('custom_login')

    # Obtener tipos de usuario e inmobiliarias para el formulario
    tipos_usuario = TipoUsuario.objects.all()
    inmobiliarias = Inmobiliaria.objects.all()
    return render(request, 'registro_usuario.html', {'tipos_usuario': tipos_usuario, 'inmobiliarias': inmobiliarias})


#Dashboard flask

@requiere_pago_aprobado
def dashboard_redirect(request):
    return redirect("http://127.0.0.1:8050/")  # Redirigir al servidor de Dash

@requiere_pago_aprobado
def dashboard_view(request):
    # Obtener el usuario autenticado desde la sesión
    usuario_id = request.session.get('usuario_id')
    usuario_actual = None

    if usuario_id:
        try:
            usuario_actual = Usuario.objects.get(id=usuario_id)
        except Usuario.DoesNotExist:
            # En caso de que el usuario no exista en la base de datos
            return redirect('custom_login')

    # Si no hay un usuario autenticado, redirigir al login
    if not usuario_actual:
        return redirect('custom_login')

    # Renderizar el template con la información del usuario
    return render(request, 'mi_app/dashboard_template.html', {'usuario_actual': usuario_actual})


#vista predicciones 
@requiere_pago_aprobado
def vista_formulario(request):
    return render(request, 'formulario_prediccion.html')


#medidas de tendencia central
@requiere_pago_aprobado
def medidas_tendencia_central(request):
    if request.method == 'GET':
        try:
            # Calcular las medidas de tendencia central para el campo "Precio UF"
            media = float(df['Precio UF'].mean())
            mediana = float(df['Precio UF'].median())
            moda = df['Precio UF'].mode().iloc[0] if not df['Precio UF'].mode().empty else None

            # Convertir la moda a un tipo de Python nativo si existe
            moda = float(moda) if moda is not None else None

            # Construir la respuesta en formato JSON
            respuesta = {
                "media": round(media, 2),
                "mediana": round(mediana, 2),
                "moda": round(moda, 2) if moda is not None else None
            }

            return JsonResponse(respuesta)
        except Exception as e:
            return JsonResponse({"error": "Error al calcular las medidas de tendencia central", "detalles": str(e)}, status=500)
    else:
        return JsonResponse({"error": "Método no permitido. Use GET."}, status=405)
    

#medidas de tendencia central por comuna
@requiere_pago_aprobado
def medidas_tendencia_central_por_comuna(request):
    """
    Calcula las medidas de tendencia central para el campo Precio UF agrupadas por comuna.
    """
    if request.method == 'GET':
        try:
            # Agrupar por comuna y calcular las medidas
            resultados = df.groupby('Comuna')['Precio UF'].agg(
                media=('mean'),
                mediana=('median'),
                moda=(lambda x: x.mode().iloc[0] if not x.mode().empty else None)
            ).reset_index()

            # Convertir los resultados a una lista de diccionarios para JSON
            respuesta = resultados.to_dict(orient='records')

            return JsonResponse(respuesta, safe=False)
        except Exception as e:
            return JsonResponse({"error": "Error al calcular las medidas de tendencia central por comuna", "detalles": str(e)}, status=500)
    else:
        return JsonResponse({"error": "Método no permitido. Use GET."}, status=405)

#Api análisis
@requiere_pago_aprobado
def api_analisis(request):
    """
    Devuelve una vista con los enlaces a los endpoints de análisis en formato HTML.
    """
    if request.method == 'GET':
        try:
            # Lista de endpoints con sus nombres descriptivos
            endpoints = [
                {"name": "Distribución de Precios por Comuna", "url": "/distribucion_precios_por_comuna/"},
                {"name": "Precios Min/Max por Comuna", "url": "/precios_min_max_por_comuna/"},
                {"name": "Medidas de Tendencia Central Valor UF Comunas sector oriente", "url": "/medidas_tendencia_central/"},
                {"name": "Medidas de Tendencia Central Valor UF por Comuna sector oriente", "url": "/medidas_tendencia_central_por_comuna/"},
            ]

            # Renderizar un fragmento HTML con los enlaces
            html_content = render_to_string('api_analisis.html', {"endpoints": endpoints})

            return JsonResponse({"html": html_content}, safe=False)
        except Exception as e:
            return JsonResponse({"error": "Error al cargar la vista de API Análisis", "detalles": str(e)}, status=500)
    else:
        return JsonResponse({"error": "Método no permitido. Use GET."}, status=405)