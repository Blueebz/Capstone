from django.urls import path

from .views import regresion_lineal, predecir_precio, metricas_modelo, distribucion_precios_por_comuna, distribucion_precio_por_comuna_especifica, precios_min_max_por_comuna_json, precios_min_max_por_comuna_post, registrar_usuario, datos_protegidos
from .views import index
from .views import CustomTokenObtainPairView
from . import views
#vistas admin
from .views import admin_dashboard, editar_usuario, eliminar_usuario, activar_usuario, custom_login
from django.contrib.auth.views import LogoutView
from django.urls import path, include
from . import views

from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView




urlpatterns = [
    path('datos_protegidos/', datos_protegidos, name='datos_protegidos'),
    path('regresion_lineal/', regresion_lineal, name='regresion_lineal'),
    path('predecir_precio/', predecir_precio, name='predecir_precio'),
    path('metricas_modelo/', metricas_modelo, name= 'metricas_modelo'),
    path('distribucion_precios_por_comuna/', distribucion_precios_por_comuna, name='distribucion_precios_por_comuna' ),
    path('distribucion_precio_por_comuna_especifica/', distribucion_precio_por_comuna_especifica, name='distribucion_precio_por_comuna_especifica'),
    path('grafico_distribucion/', views.grafico_distribucion_precios, name='grafico_distribucion'),
    path('distribucion_json/', views.distribucion_precios_json, name='distribucion_json'),
    path('mostrar_grafico/', views.mostrar_grafico_html, name='mostrar_grafico'),
    path('mostrar_grafico_por_comuna/', views.distribucion_precios_por_comuna_grafico, name='mostrar_grafico_por_comuna'),
    path('precios-min-max/', views.precios_min_max_por_comuna, name='precios_min_max'),
    path('precios_min_max_por_comuna/', precios_min_max_por_comuna_json, name='precios_min_max_por_comuna'),
    path('precios-comuna/', precios_min_max_por_comuna_post, name='precios_min_max_por_comuna_post'),
    # Rutas para JWT
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('api/token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    # Creación de usuario
    path('registrar_usuario/', views.registrar_usuario, name='registrar_usuario'),
    #Vista admin
    path('admin/dashboard/', admin_dashboard, name='admin_dashboard'),
    path('admin/usuario/<int:user_id>/editar/', editar_usuario, name='editar_usuario'),
    path('admin/usuario/<int:user_id>/eliminar/', eliminar_usuario, name='eliminar_usuario'),
    path('admin/usuario/<int:user_id>/activar/', activar_usuario, name='activar_usuario'),
    #Login
    path('login/', custom_login, name='custom_login'),
    #Logout
    path('logout/', views.custom_logout, name='custom_logout'),
    #index
    path('', index, name='index'),
    # User Dashboard (dashboard del usuario)
    path('user_dashboard/', views.user_dashboard, name='user_dashboard'),
    # Procesar Pago
    path('procesar_pago/', views.procesar_pago, name='procesar_pago'),
    #dashboard flask
    path('dashboard/', views.dashboard_redirect, name='dashboard'),
    #Vista predicciones
     path('formulario/', views.vista_formulario, name='formulario'),  # Ruta para mostrar el formulario
    #medidas de tendencia central
    path('medidas_tendencia_central/', views.medidas_tendencia_central, name='medidas_tendencia_central'),
    #Medidas de tendencia central por comuna
    path('medidas_tendencia_central_por_comuna/', views.medidas_tendencia_central_por_comuna, name='medidas_tendencia_central_por_comuna'),
    #acceso a api_analisis
    path('api_analisis/', views.api_analisis, name='api_analisis'),


] 
