// Función para obtener el valor del token CSRF de las cookies
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            // Verifica si este fragmento de cookie coincide con el nombre dado
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

function hacerPrediccion() {
    const data = {
        "Comuna": document.getElementById("comuna").value,
        "Superficie": parseFloat(document.getElementById("superficie").value),
        "Dormitorios": parseInt(document.getElementById("dormitorios").value),
        "Baños": parseInt(document.getElementById("banos").value),
        "Estacionamiento": parseInt(document.getElementById("estacionamiento").value)
    };

    fetch('/predecir_precio/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken') // Obtener el token CSRF
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            document.getElementById('resultado-prediccion').innerText = `Error: ${data.error}`;
        } else {
            document.getElementById('resultado-prediccion').innerText = `El precio predicho es: ${data.prediccion} UF`;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('resultado-prediccion').innerText = "Hubo un error al hacer la predicción.";
    });
}
