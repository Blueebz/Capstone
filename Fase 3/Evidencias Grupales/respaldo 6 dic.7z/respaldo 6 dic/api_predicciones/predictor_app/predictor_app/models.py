from datetime import datetime
from django.db import models

# Modelo para representar el tipo de usuario
class TipoUsuario(models.Model):
    nombre = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.nombre

# Modelo para representar una inmobiliaria
class Inmobiliaria(models.Model):
    nombre = models.CharField(max_length=255, unique=True)
    descripcion = models.TextField(null=True, blank=True)
    contacto = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return self.nombre

# Modelo para representar un usuario
class Usuario(models.Model):
    id = models.AutoField(primary_key=True)
    rut_numero = models.CharField(max_length=10)
    rut_dv = models.CharField(max_length=1)
    primer_nombre = models.CharField(max_length=100)
    segundo_nombre = models.CharField(max_length=100, null=True, blank=True)
    apellido_p = models.CharField(max_length=100)
    apellido_m = models.CharField(max_length=100, null=True, blank=True)
    fecha_cumpleanos = models.DateField()
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=255)
    salt = models.CharField(max_length=12)  # Para almacenar el salt usado en el hash de la contraseña
    tipo_usuario = models.ForeignKey('TipoUsuario', on_delete=models.CASCADE)
    inmobiliaria_asociada = models.ForeignKey('Inmobiliaria', on_delete=models.SET_NULL, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    fecha_actualizacion = models.DateTimeField(auto_now=True)
    

    def ha_pagado(self):
        return Pago.objects.filter(usuario=self, estado='Aprobado', valido_hasta__gte=datetime.now()).exists()

    class Meta:
        db_table = 'usuarios'

# Modelo para representar los pagos realizados por los usuarios
class Pago(models.Model):
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='pagos_realizados')
    monto = models.DecimalField(max_digits=10, decimal_places=2)
    estado = models.CharField(max_length=50, choices=[
        ('Pendiente', 'Pendiente'),
        ('Aprobado', 'Aprobado'),
        ('Rechazado', 'Rechazado')
    ])
    fecha_pago = models.DateTimeField(auto_now_add=True)
    valido_hasta = models.DateTimeField()
    metodo_pago = models.CharField(max_length=100)

    def __str__(self):
        return f"Pago {self.id} - {self.usuario.email}"
