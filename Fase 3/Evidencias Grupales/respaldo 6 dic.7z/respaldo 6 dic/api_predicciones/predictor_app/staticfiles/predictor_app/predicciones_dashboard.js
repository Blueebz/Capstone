function hacerPrediccion() {
    const data = {
        "Superficie": document.getElementById("superficie").value,
        "Dormitorios": document.getElementById("dormitorios").value,
        "Baños": document.getElementById("banos").value,
        "Estacionamiento": document.getElementById("estacionamiento").value
    };

    fetch('/predecir_precio/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken') // Obtenemos el CSRF token para seguridad
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('resultado-prediccion').innerText = `El precio predicho es: ${data.prediccion} UF`;
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('resultado-prediccion').innerText = "Hubo un error al hacer la predicción.";
    });
}

function mostrarGraficoComuna() {
    const comuna = document.getElementById("comuna").value;

    fetch('/distribucion_precio_por_comuna_especifica/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken') // Token CSRF
        },
        body: JSON.stringify({ "comuna": comuna })
    })
    .then(response => response.json())
    .then(data => {
        if (data.graphic) {
            const img = document.createElement('img');
            img.src = 'data:image/png;base64,' + data.graphic;
            document.getElementById('grafico-comuna').innerHTML = '';
            document.getElementById('grafico-comuna').appendChild(img);
        } else {
            document.getElementById('grafico-comuna').innerText = "No se pudo generar el gráfico.";
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('grafico-comuna').innerText = "Hubo un error al obtener el gráfico.";
    });
}

// Función para obtener el CSRF token de las cookies
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
