import psycopg2
import pandas as pd

# Paso 1: Cargar el CSV usando pandas
csv_file_path = 'df_filtered_predicciones.csv'
df = pd.read_csv(csv_file_path)

# Paso 2: Conectar a la base de datos PostgreSQL
conn = psycopg2.connect(
    dbname="departamentos", 
    user="postgres", 
    password="1234",  # Cambia la contraseña si es necesario
    host="127.0.0.1", 
    port="5432"
)

# Crear un cursor para realizar operaciones
cur = conn.cursor()

# Paso 3: Insertar datos en la tabla prediccion_propiedades
for index, row in df.iterrows():
    cur.execute("""
        INSERT INTO prediccion_propiedades (direccion, precio_uf, dormitorios, baños, superficie, estacionamiento, bodega, comuna, bodega_bin, estacionamiento_bin, la_reina, providencia, nunoa, vitacura, lo_barnechea, las_condes)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
        row['Dirección'],
        row['Precio UF'],
        row['Dormitorios'],
        row['Baños'],
        row['Superficie'],
        row['Estacionamiento'],
        row['Bodega'],
        row['Comuna'],
        row['Bodega_Bin'],
        row['Estacionamiento_Bin'],
        row['La Reina'],
        row['Providencia'],
        row['Nunoa'],
        row['Vitacura'],
        row['Lo Barnechea'],
        row['Las Condes']
    ))

# Confirmar la transacción
conn.commit()

# Cerrar el cursor y la conexión
cur.close()
conn.close()

print("Datos insertados correctamente en la base de datos")
