import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import pickle

# Cargar los datos
df = pd.read_csv('df_filtered_predicciones_2_no_zero_superficie.csv')

# Definir X (variables independientes) y Y (variable dependiente)
X = df[['Baños', 'Dormitorios', 'Superficie', 'Estacionamiento', 
        'La Reina', 'Providencia', 'Nunoa', 'Vitacura', 'Lo Barnechea', 'Las Condes']]
Y = df['Precio UF']

# Dividir en conjuntos de entrenamiento y prueba
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

# Crear y entrenar el modelo
modelo = LinearRegression()
modelo.fit(X_train, Y_train)

# Guardar el modelo en un archivo
with open('modelo_regresion_lineal_2.pkl', 'wb') as f:
    pickle.dump(modelo, f)

print("Modelo guardado exitosamente.")
