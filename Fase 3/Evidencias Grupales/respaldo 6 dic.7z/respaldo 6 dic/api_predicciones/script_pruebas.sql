#pruebas

#insertar inmobiliaria
INSERT INTO predictor_app_inmobiliaria (nombre, descripcion, contacto)
VALUES ('Inmobiliaria Ejemplo', 'Una inmobiliaria de ejemplo', 'contacto@inmobiliariaejemplo.com');

INSERT INTO predictor_app_inmobiliaria (nombre, descripcion, contacto) 
VALUES ('Inmobiliaria Test', 'Descripción de prueba', 'test@example.com');


#Insertar tipos de usuario

INSERT INTO predictor_app_tipousuario (nombre)
VALUES ('Cliente'), ('Corredor');

# Insertar usuario
INSERT INTO usuarios (
    primer_nombre,
    segundo_nombre,
    apellido_p,
    apellido_m,
    rut_numero,
    rut_dv,
    fecha_cumpleanos,
    email,
    password,
    tipo_usuario_id,
    inmobiliaria_asociada_id,
    is_active,
    is_admin,
    fecha_creacion,
    fecha_actualizacion
)
VALUES (
    'Juan', 
    'Carlos', 
    'Pérez', 
    'Gómez', 
    '12345678', 
    '9', 
    '1990-05-20', 
    'juan.perez@example.com', 
    'contraseña_segura',  -- Recuerda hashear las contraseñas para producción.
    1,  -- ID del tipo de usuario 'Cliente'
    1,  -- ID de la inmobiliaria 'Inmobiliaria Ejemplo'
    TRUE,
    FALSE,
    NOW(),  -- `fecha_creacion`, se establece con la fecha y hora actuales
    NOW()   -- `fecha_actualizacion`, se establece con la fecha y hora actuales
);

#Insertar usuario con inmobiliaria asociada
INSERT INTO usuarios (
    primer_nombre,
    segundo_nombre,
    apellido_p,
    apellido_m,
    rut_numero,
    rut_dv,
    fecha_cumpleanos,
    email,
    password,
    tipo_usuario_id,
    inmobiliaria_asociada_id,
    is_active,
    is_admin,
    fecha_creacion,
    fecha_actualizacion
)
VALUES (
    'Pedro', 
    'Luis', 
    'Sánchez', 
    'Ortiz', 
    '87654321', 
    '5', 
    '1985-12-15', 
    'pedro.sanchez@example.com', 
    'otra_contraseña_segura', 
    1,  -- ID del tipo de usuario 'Cliente'
    2,  -- ID de la inmobiliaria 'Inmobiliaria Test'
    TRUE,
    FALSE,
    NOW(),
    NOW()
);

#usuario tipo admin
INSERT INTO usuarios (
    primer_nombre,
    segundo_nombre,
    apellido_p,
    apellido_m,
    rut_numero,
    rut_dv,
    fecha_cumpleanos,
    email,
    password,
    tipo_usuario_id,
    inmobiliaria_asociada_id,
    is_active,
    is_admin,
    fecha_creacion,
    fecha_actualizacion
) VALUES (
    'Admin',
    NULL,
    'Administrador',
    'General',
    '12345678',
    '9',
    '1990-01-01',
    'admin@example.com',
    'contraseña_segura',  -- Recuerda cifrar la contraseña en un entorno de producción
    1,  -- ID del tipo de usuario que corresponde a "Administrador"
    NULL,
    TRUE,
    TRUE,
    NOW(),
    NOW()
);


#Selectores

SELECT * FROM predictor_app_inmobiliaria;
SELECT * FROM predictor_app_tipousuario;
SELECT * FROM usuarios;

#Selector join con user e inmobiliaria
SELECT u.primer_nombre, u.apellido_p, u.email, i.nombre AS inmobiliaria
FROM usuarios u
LEFT JOIN predictor_app_inmobiliaria i ON u.inmobiliaria_asociada_id = i.id;


