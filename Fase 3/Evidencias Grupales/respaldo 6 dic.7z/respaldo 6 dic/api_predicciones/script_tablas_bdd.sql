CREATE TABLE tipo_usuario (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL
);


CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    rut_numero VARCHAR(10) NOT NULL,
    rut_dv CHAR(1) NOT NULL,
    primer_nombre VARCHAR(100),
    segundo_nombre VARCHAR(100),
    apellido_p VARCHAR(100),
    apellido_m VARCHAR(100),
    fecha_cumpleanos DATE,
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255) NOT NULL,  -- Campo para la contraseña (hash)
    tipo_usuario INTEGER REFERENCES tipo_usuario(id),
    is_payed BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,  -- Campo para indicar si el usuario está activo
    auth_token VARCHAR(255),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_admin BOOLEAN DEFAULT FALSE
);


##Poblar tablas 


INSERT INTO usuarios (rut_numero, rut_dv, primer_nombre, apellido_p, fecha_cumpleanos, email, password, tipo_usuario, is_payed, is_admin)
VALUES 
('12345678', '9', 'Ana', 'González', '1990-05-15', 'ana.gomez@example.com', 'contrasena_segura_ana', 2, TRUE, FALSE),
('87654321', '4', 'Pedro', 'Sánchez', '1985-02-20', 'pedro.sanchez@example.com', 'contrasena_segura_pedro', 1, FALSE, FALSE);




