import pandas as pd

# Cargar el archivo Excel
df = pd.read_excel('df_filtered_predicciones.xlsx')

# Guardar como CSV
df.to_csv('df_filtered_predicciones.csv', index=False)
