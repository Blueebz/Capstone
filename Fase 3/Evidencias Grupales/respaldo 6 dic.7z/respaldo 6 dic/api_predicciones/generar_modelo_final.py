import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import joblib

# Cargar los datos
df = pd.read_csv('df_filtered_predicciones_2_no_zero_superficie.csv')

# Definir X (variables independientes) y Y (variable dependiente)
X = df[['Baños', 'Dormitorios', 'Superficie', 'Estacionamiento', 
        'La Reina', 'Providencia', 'Nunoa', 'Vitacura', 'Lo Barnechea', 'Las Condes']]
Y = df['Precio UF']

# Dividir en conjuntos de entrenamiento y prueba
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

# Crear y entrenar el modelo
modelo = LinearRegression()
modelo.fit(X_train, Y_train)

# Guardar el modelo en un archivo usando joblib
joblib_file_path = 'modelo_regresion_final.pkl'
joblib.dump(modelo, joblib_file_path)

print(f"Modelo guardado exitosamente como '{joblib_file_path}'")
