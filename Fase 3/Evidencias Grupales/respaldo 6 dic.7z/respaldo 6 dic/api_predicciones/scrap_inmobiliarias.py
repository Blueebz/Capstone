from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import json
import time
import random

# Configuración del WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

urls = [
    "https://bancoestado.enlaceinmobiliario.cl/inmobiliarias?&p=01",
    "https://bancoestado.enlaceinmobiliario.cl/inmobiliarias?&p=02"
]

inmobiliarias = []

# Recorremos las URLs para scrapear cada una
for url in urls:
    driver.get(url)
    
    # Esperar un tiempo aleatorio para simular comportamiento humano
    time.sleep(random.uniform(5, 10))
    
    try:
        # Esperar hasta que los nombres de las inmobiliarias estén presentes
        nombres_inmobiliarias = WebDriverWait(driver, 20).until(
            EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.inner > a > h2"))
        )
        
        if not nombres_inmobiliarias:
            print(f"No se encontraron elementos h2 en {url}")
        else:
            for nombre in nombres_inmobiliarias:
                inmobiliarias.append({"nombre": nombre.text})
    
    except Exception as e:
        print(f"Error al extraer los nombres de inmobiliarias de {url}: {e}")

# Guardar los resultados en un archivo JSON
if inmobiliarias:
    with open('inmobiliarias.json', 'w', encoding='utf-8') as f:
        json.dump(inmobiliarias, f, ensure_ascii=False, indent=4)
    print("Datos guardados en 'inmobiliarias.json'")
else:
    print("No se pudo extraer ninguna inmobiliaria.")

# Cerrar el navegador
driver.quit()
