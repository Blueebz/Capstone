from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import time

# Configuración del WebDriver
driver = webdriver.Chrome()

# URL de la página inicial de las propiedades
url = 'https://www.toctoc.com/venta/departamento/metropolitana/vitacura'

# Número de páginas que quieres recorrer
num_paginas = 12  # Puedes ajustar este valor según necesites

# Cargar la página principal
driver.get(url)
time.sleep(5)  # Esperar a que la página cargue completamente

# Lista para almacenar los datos
data = []

def scroll_until_element_found(selector):
    """
    Realiza scroll hacia abajo hasta encontrar el elemento especificado por el selector.
    """
    while True:
        try:
            element = driver.find_element(By.CSS_SELECTOR, selector)
            driver.execute_script("arguments[0].scrollIntoView();", element)
            break
        except Exception as e:
            driver.execute_script("window.scrollBy(0, 500);")  # Hacer scroll hacia abajo
            time.sleep(2)  # Esperar un momento para permitir que la página cargue

for _ in range(num_paginas):
    # Obtener todas las tarjetas de propiedades en la página principal
    cards = driver.find_elements(By.CSS_SELECTOR, 'a.contenedorCard-ds')
    
    # Iterar sobre cada tarjeta para obtener los detalles
    for card in cards:
        try:
            # Extraer la URL del detalle de la propiedad
            detail_url = card.get_attribute('href')
            
            # Abrir el detalle de la propiedad en una nueva ventana
            driver.execute_script(f"window.open('{detail_url}');")
            driver.switch_to.window(driver.window_handles[1])  # Cambiar a la nueva pestaña
            time.sleep(5)  # Esperar a que la página cargue completamente

            # Extraer la dirección
            try:
                direccion = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, 'ul.cabecera-ubicacion li.dir div.d-flex'))
                ).text.strip()
            except Exception as e:
                print(f"Error al extraer la dirección: {e}")
                direccion = "N/A"
            
            # Extraer el tipo de propiedad
            try:
                tipo = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, 'h1.tipo.nv'))
                ).text.strip()
            except Exception as e:
                print(f"Error al extraer el tipo de propiedad: {e}")
                tipo = "N/A"
            
            # Extraer el nombre del proyecto
            try:
                nombre_proyecto = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, 'h2.nom-proyecto'))
                ).text.strip()
            except Exception as e:
                print(f"Error al extraer el nombre del proyecto: {e}")
                nombre_proyecto = "N/A"
            
            # Extraer el precio en UF
            try:
                precio_uf = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, 'p.precio-uf'))
                ).text.strip()
            except Exception as e:
                print(f"Error al extraer el precio en UF: {e}")
                precio_uf = "N/A"
            
            # Extraer el precio en CLP
            try:
                precio_clp = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, 'p.precio-alt'))
                ).text.strip()
            except Exception as e:
                print(f"Error al extraer el precio en CLP: {e}")
                precio_clp = "N/A"

            # Extraer el número de dormitorios
            try:
                dormitorios = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, '//h4[text()="Dormitorios:"]/following-sibling::strong'))
                ).text.strip()
            except Exception as e:
                print(f"Error al extraer el número de dormitorios: {e}")
                dormitorios = "N/A"

            # Extraer el número de baños
            try:
                banos = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, '//h4[text()="Baños:"]/following-sibling::strong'))
                ).text.strip()
            except Exception as e:
                print(f"Error al extraer el número de baños: {e}")
                banos = "N/A"

            # Extraer la superficie útil
            try:
                superficie = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, '//h4[text()="Superficie útil:"]/following-sibling::strong'))
                ).text.strip()
            except Exception as e:
                print(f"Error al extraer la superficie útil: {e}")
                superficie = "N/A"

            # Scroll hasta encontrar el botón "Cómo llegar"
            scroll_until_element_found('a.btn-outline')

            # Hacer clic en el botón "Cómo llegar"
            try:
                boton_como_llegar = driver.find_element(By.CSS_SELECTOR, 'a.btn-outline')
                driver.execute_script("arguments[0].scrollIntoView();", boton_como_llegar)  # Asegurarse de que el botón sea visible
                boton_como_llegar.click()
                driver.switch_to.window(driver.window_handles[2])  # Cambiar a la nueva pestaña (Google Maps)
                time.sleep(5)  # Esperar a que la página cargue completamente

                # Extraer la dirección desde Google Maps
                try:
                    direccion_maps = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, 'span.DkEaL'))
                    ).text.strip()
                except Exception as e:
                    print(f"Error al extraer la dirección desde Google Maps: {e}")
                    direccion_maps = "N/A"

                # Volver a la pestaña de detalle
                driver.close()
                driver.switch_to.window(driver.window_handles[1])
            except Exception as e:
                print(f"Error al procesar el botón 'Cómo llegar': {e}")
                direccion_maps = "N/A"

            # Agregar los datos a la lista
            data.append({
                'URL': detail_url,
                'Tipo': tipo,
                'Nombre Proyecto': nombre_proyecto,
                'Dirección': direccion_maps,  # Usar la dirección extraída desde Google Maps
                'Precio UF': precio_uf,
                'Precio CLP': precio_clp,
                'Dormitorios': dormitorios,
                'Baños': banos,
                'Superficie': superficie
            })

            # Cerrar la pestaña de detalle y volver a la pestaña principal
            driver.close()
            driver.switch_to.window(driver.window_handles[0])

        except Exception as e:
            print(f'Error al procesar la tarjeta: {e}')
            driver.close()
            driver.switch_to.window(driver.window_handles[0])

    # Intentar hacer clic en el botón "Siguiente"
    try:
        next_button = driver.find_element(By.CSS_SELECTOR, 'button[aria-label="Go to next page"]')
        if "Mui-disabled" in next_button.get_attribute("class"):
            print("El botón 'Siguiente' está deshabilitado. Fin del scraping en esta URL.")
            break
        else:
            next_button.click()
            time.sleep(5)  # Esperar a que la página siguiente cargue completamente
    except Exception as e:
        print(f"Error al intentar cambiar de página: {e}")
        break

# Convertir la lista de datos en un DataFrame de pandas
df = pd.DataFrame(data)

# Guardar los datos en un archivo Excel
df.to_excel('detalle_deptos_compra_vitacura.xlsx', index=False)

# Cerrar el navegador
driver.quit()

print("Scraping completado y datos guardados en 'detalle_deptos_compra_vitacura.xlsx'")
